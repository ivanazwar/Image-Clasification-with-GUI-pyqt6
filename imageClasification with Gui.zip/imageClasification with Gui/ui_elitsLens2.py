# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'elitsLens.ui'
##
## Created by: Qt User Interface Compiler version 6.8.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QLabel, QMainWindow,
    QMenuBar, QProgressBar, QPushButton, QSizePolicy,
    QStatusBar, QWidget)
import resources_rc
import resources_rc

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1521, 800)
        MainWindow.setStyleSheet(u"background-color: rgb(18, 18, 18);")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.widget = QWidget(self.centralwidget)
        self.widget.setObjectName(u"widget")
        self.widget.setGeometry(QRect(20, 80, 641, 661))
        self.widget.setStyleSheet(u"QWidget{\n"
"background-color: rgb(25, 25, 25);\n"
" border-radius: 5px; \n"
"}")
        self.widget_image = QLabel(self.widget)
        self.widget_image.setObjectName(u"widget_image")
        self.widget_image.setGeometry(QRect(10, 10, 621, 451))
        self.widget_image.setPixmap(QPixmap(u":/icon/Desain tanpa judul.png"))
        self.widget_image.setScaledContents(True)
        self.pb_choseimage2 = QPushButton(self.widget)
        self.pb_choseimage2.setObjectName(u"pb_choseimage2")
        self.pb_choseimage2.setGeometry(QRect(570, 400, 71, 71))
        font = QFont()
        font.setFamilies([u"Comic Sans MS"])
        font.setPointSize(48)
        font.setBold(True)
        self.pb_choseimage2.setFont(font)
        self.pb_choseimage2.setStyleSheet(u"QPushButton{\n"
"color:white;\n"
"border:none;\n"
"background-color: #D10363;\n"
"border-radius:35px;\n"
"}\n"
"\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #D10363;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #EB3678;\n"
"}\n"
"")
        self.pb_choseimage2.setIconSize(QSize(30, 30))
        self.pb_choseimage2.setCheckable(False)
        self.pb_choseimage2.setAutoExclusive(False)
        self.pb_choseimage = QPushButton(self.widget)
        self.pb_choseimage.setObjectName(u"pb_choseimage")
        self.pb_choseimage.setGeometry(QRect(10, 480, 201, 81))
        font1 = QFont()
        font1.setFamilies([u"Comic Sans MS"])
        font1.setPointSize(12)
        font1.setBold(True)
        self.pb_choseimage.setFont(font1)
        self.pb_choseimage.setStyleSheet(u"QPushButton{\n"
"color:white;\n"
"border:none;\n"
"background-color: rgb(55, 0, 179);\n"
"border-radius:10px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgb(98, 0, 238);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #BB86FC;\n"
"}\n"
"\n"
"")
        icon = QIcon()
        icon.addFile(u":/res/icon/photo (1).png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pb_choseimage.setIcon(icon)
        self.pb_choseimage.setIconSize(QSize(30, 30))
        self.pb_choseimage.setCheckable(False)
        self.pb_choseimage.setAutoExclusive(False)
        self.pb_deletimage = QPushButton(self.widget)
        self.pb_deletimage.setObjectName(u"pb_deletimage")
        self.pb_deletimage.setGeometry(QRect(10, 570, 201, 81))
        self.pb_deletimage.setFont(font1)
        self.pb_deletimage.setStyleSheet(u"QPushButton{\n"
"color:white;\n"
"border:none;\n"
"background-color: #740938;\n"
"border-radius:10px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #AF1740\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #CC2B52\n"
"}\n"
"\n"
"")
        icon1 = QIcon()
        icon1.addFile(u":/icon/delete.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pb_deletimage.setIcon(icon1)
        self.pb_deletimage.setIconSize(QSize(30, 30))
        self.pb_deletimage.setCheckable(False)
        self.pb_deletimage.setAutoExclusive(False)
        self.pb_opencamera = QPushButton(self.widget)
        self.pb_opencamera.setObjectName(u"pb_opencamera")
        self.pb_opencamera.setGeometry(QRect(220, 480, 71, 81))
        self.pb_opencamera.setFont(font1)
        self.pb_opencamera.setStyleSheet(u"QPushButton{\n"
"color:white;\n"
"border:none;\n"
"background-color: rgb(235, 131, 23);\n"
"border-radius:10px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgb(235, 131, 23);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #F3C623\n"
"}\n"
"\n"
"")
        icon2 = QIcon()
        icon2.addFile(u":/icon/photo-camera.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pb_opencamera.setIcon(icon2)
        self.pb_opencamera.setIconSize(QSize(40, 40))
        self.pb_opencamera.setCheckable(False)
        self.pb_opencamera.setAutoExclusive(False)
        self.pb_closecamera = QPushButton(self.widget)
        self.pb_closecamera.setObjectName(u"pb_closecamera")
        self.pb_closecamera.setGeometry(QRect(300, 480, 71, 81))
        self.pb_closecamera.setFont(font1)
        self.pb_closecamera.setStyleSheet(u"QPushButton{\n"
"color:white;\n"
"border:none;\n"
"background-color: rgb(235, 131, 23);\n"
"border-radius:10px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgb(235, 131, 23);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #F3C623\n"
"}\n"
"\n"
"")
        icon3 = QIcon()
        icon3.addFile(u":/icon/camera.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pb_closecamera.setIcon(icon3)
        self.pb_closecamera.setIconSize(QSize(40, 40))
        self.pb_closecamera.setCheckable(False)
        self.pb_closecamera.setAutoExclusive(False)
        self.pb_visibleslectarea = QPushButton(self.widget)
        self.pb_visibleslectarea.setObjectName(u"pb_visibleslectarea")
        self.pb_visibleslectarea.setGeometry(QRect(220, 570, 71, 81))
        self.pb_visibleslectarea.setFont(font1)
        self.pb_visibleslectarea.setStyleSheet(u"QPushButton{\n"
"color:white;\n"
"border:none;\n"
"background-color: rgb(235, 131, 23);\n"
"border-radius:10px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgb(235, 131, 23);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #F3C623\n"
"}\n"
"\n"
"")
        icon4 = QIcon()
        icon4.addFile(u":/icon/area.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pb_visibleslectarea.setIcon(icon4)
        self.pb_visibleslectarea.setIconSize(QSize(40, 40))
        self.pb_visibleslectarea.setCheckable(False)
        self.pb_visibleslectarea.setAutoExclusive(False)
        self.pb_hideslectarea = QPushButton(self.widget)
        self.pb_hideslectarea.setObjectName(u"pb_hideslectarea")
        self.pb_hideslectarea.setGeometry(QRect(300, 570, 71, 81))
        self.pb_hideslectarea.setFont(font1)
        self.pb_hideslectarea.setStyleSheet(u"QPushButton{\n"
"color:white;\n"
"border:none;\n"
"background-color: rgb(235, 131, 23);\n"
"border-radius:10px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgb(235, 131, 23);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #F3C623\n"
"}\n"
"\n"
"")
        icon5 = QIcon()
        icon5.addFile(u":/icon/eye.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pb_hideslectarea.setIcon(icon5)
        self.pb_hideslectarea.setIconSize(QSize(60, 60))
        self.pb_hideslectarea.setCheckable(False)
        self.pb_hideslectarea.setAutoExclusive(False)
        self.pb_processImage = QPushButton(self.widget)
        self.pb_processImage.setObjectName(u"pb_processImage")
        self.pb_processImage.setGeometry(QRect(380, 480, 251, 81))
        self.pb_processImage.setFont(font1)
        self.pb_processImage.setStyleSheet(u"QPushButton{\n"
"color:white;\n"
"border:none;\n"
"background-color: #006769;\n"
"border-radius:10px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #40A578;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #40A579;\n"
"}\n"
"\n"
"")
        icon6 = QIcon()
        icon6.addFile(u":/icon/image-processing.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pb_processImage.setIcon(icon6)
        self.pb_processImage.setIconSize(QSize(100, 100))
        self.pb_processImage.setCheckable(False)
        self.pb_processImage.setAutoExclusive(False)
        self.pb_captureImage = QPushButton(self.widget)
        self.pb_captureImage.setObjectName(u"pb_captureImage")
        self.pb_captureImage.setGeometry(QRect(380, 570, 251, 81))
        self.pb_captureImage.setFont(font1)
        self.pb_captureImage.setStyleSheet(u"QPushButton{\n"
"color:white;\n"
"border:none;\n"
"background-color:#161D6F;\n"
"border-radius:10px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #0B2F9F;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color:#98DED9;\n"
"}\n"
"\n"
"")
        icon7 = QIcon()
        icon7.addFile(u":/icon/capture.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pb_captureImage.setIcon(icon7)
        self.pb_captureImage.setIconSize(QSize(100, 100))
        self.pb_captureImage.setCheckable(False)
        self.pb_captureImage.setAutoExclusive(False)
        self.widget_3 = QWidget(self.centralwidget)
        self.widget_3.setObjectName(u"widget_3")
        self.widget_3.setGeometry(QRect(670, 20, 421, 331))
        self.widget_3.setStyleSheet(u"QWidget{\n"
"background-color: rgb(25, 25, 25);\n"
" border-radius: 5px; \n"
"}")
        self.widget_output = QLabel(self.widget_3)
        self.widget_output.setObjectName(u"widget_output")
        self.widget_output.setGeometry(QRect(0, 0, 421, 331))
        self.widget_output.setPixmap(QPixmap(u":/icon/Please Insert Image (1).png"))
        self.widget_output.setScaledContents(True)
        self.widget_6 = QWidget(self.centralwidget)
        self.widget_6.setObjectName(u"widget_6")
        self.widget_6.setGeometry(QRect(670, 640, 841, 101))
        self.widget_6.setStyleSheet(u"QWidget{\n"
"background-color: rgb(25, 25, 25);\n"
" border-radius: 5px; \n"
"}")
        self.widget_7 = QWidget(self.widget_6)
        self.widget_7.setObjectName(u"widget_7")
        self.widget_7.setGeometry(QRect(240, 310, 381, 341))
        self.widget_7.setStyleSheet(u"QWidget{\n"
"background-color: rgb(25, 25, 25);\n"
" border-radius: 5px; \n"
"}")
        self.widget_8 = QWidget(self.widget_6)
        self.widget_8.setObjectName(u"widget_8")
        self.widget_8.setGeometry(QRect(-190, 290, 601, 131))
        self.widget_8.setStyleSheet(u"QWidget{\n"
"background-color: rgb(25, 25, 25);\n"
" border-radius: 5px; \n"
"}")
        self.widget_10 = QWidget(self.widget_8)
        self.widget_10.setObjectName(u"widget_10")
        self.widget_10.setGeometry(QRect(240, 310, 381, 341))
        self.widget_10.setStyleSheet(u"QWidget{\n"
"background-color: rgb(25, 25, 25);\n"
" border-radius: 5px; \n"
"}")
        self.label_37 = QLabel(self.widget_6)
        self.label_37.setObjectName(u"label_37")
        self.label_37.setGeometry(QRect(10, 0, 91, 31))
        font2 = QFont()
        font2.setFamilies([u"Yu Gothic UI Semibold"])
        font2.setPointSize(15)
        font2.setBold(True)
        self.label_37.setFont(font2)
        self.label_37.setLayoutDirection(Qt.LeftToRight)
        self.label_37.setAutoFillBackground(False)
        self.label_37.setStyleSheet(u"color: rgb(217, 217, 217);\n"
"")
        self.label_37.setTextFormat(Qt.AutoText)
        self.label_37.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)
        self.lbl_result = QLabel(self.widget_6)
        self.lbl_result.setObjectName(u"lbl_result")
        self.lbl_result.setGeometry(QRect(120, 0, 671, 91))
        font3 = QFont()
        font3.setFamilies([u"Yu Gothic UI Semibold"])
        font3.setPointSize(54)
        font3.setBold(True)
        self.lbl_result.setFont(font3)
        self.lbl_result.setLayoutDirection(Qt.LeftToRight)
        self.lbl_result.setAutoFillBackground(False)
        self.lbl_result.setStyleSheet(u"color: rgb(217, 217, 217);\n"
"")
        self.lbl_result.setTextFormat(Qt.AutoText)
        self.lbl_result.setAlignment(Qt.AlignBottom|Qt.AlignLeading|Qt.AlignLeft)
        self.widget_13 = QWidget(self.centralwidget)
        self.widget_13.setObjectName(u"widget_13")
        self.widget_13.setGeometry(QRect(670, 360, 421, 271))
        self.widget_13.setStyleSheet(u"QWidget{\n"
"background-color: rgb(30, 30, 30);\n"
" border-radius: 5px; \n"
"}")
        self.label_35 = QLabel(self.widget_13)
        self.label_35.setObjectName(u"label_35")
        self.label_35.setGeometry(QRect(10, 0, 111, 31))
        font4 = QFont()
        font4.setFamilies([u"Yu Gothic UI Semibold"])
        font4.setPointSize(11)
        font4.setBold(True)
        self.label_35.setFont(font4)
        self.label_35.setLayoutDirection(Qt.LeftToRight)
        self.label_35.setAutoFillBackground(False)
        self.label_35.setStyleSheet(u"color: rgb(217, 217, 217);\n"
"")
        self.label_35.setTextFormat(Qt.AutoText)
        self.label_35.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)
        self.lbl_description = QLabel(self.widget_13)
        self.lbl_description.setObjectName(u"lbl_description")
        self.lbl_description.setGeometry(QRect(10, 30, 401, 231))
        self.lbl_description.setFont(font4)
        self.lbl_description.setLayoutDirection(Qt.LeftToRight)
        self.lbl_description.setAutoFillBackground(False)
        self.lbl_description.setStyleSheet(u"color: rgb(217, 217, 217);\n"
"")
        self.lbl_description.setFrameShape(QFrame.Box)
        self.lbl_description.setTextFormat(Qt.MarkdownText)
        self.lbl_description.setScaledContents(True)
        self.lbl_description.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignTop)
        self.lbl_description.setWordWrap(True)
        self.label_25 = QLabel(self.centralwidget)
        self.label_25.setObjectName(u"label_25")
        self.label_25.setGeometry(QRect(1110, 27, 51, 16))
        self.label_25.setFont(font4)
        self.label_25.setLayoutDirection(Qt.LeftToRight)
        self.label_25.setAutoFillBackground(False)
        self.label_25.setStyleSheet(u"color: rgb(217, 217, 217);\n"
"")
        self.label_25.setTextFormat(Qt.AutoText)
        self.label_25.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)
        self.pb_botol = QProgressBar(self.centralwidget)
        self.pb_botol.setObjectName(u"pb_botol")
        self.pb_botol.setGeometry(QRect(1110, 50, 381, 16))
        font5 = QFont()
        font5.setPointSize(8)
        font5.setBold(False)
        font5.setStrikeOut(False)
        font5.setKerning(True)
        self.pb_botol.setFont(font5)
        self.pb_botol.setStyleSheet(u"QProgressBar {\n"
"    background-color: rgb(200, 200, 200);\n"
"    color: rgb(255, 255, 255);\n"
"    border-style: solid;\n"
"    border-radius: 8px;\n"
"    text-align: center;\n"
"}\n"
"\n"
"QProgressBar::chunk {\n"
"    border-radius: 8px;\n"
"    background: rgb(26, 188, 156)\n"
"}\n"
"")
        self.pb_botol.setMinimum(0)
        self.pb_botol.setValue(0)
        self.pb_botol.setInvertedAppearance(False)
        self.pb_dompet = QProgressBar(self.centralwidget)
        self.pb_dompet.setObjectName(u"pb_dompet")
        self.pb_dompet.setGeometry(QRect(1110, 100, 381, 16))
        self.pb_dompet.setFont(font5)
        self.pb_dompet.setStyleSheet(u"QProgressBar {\n"
"    background-color: rgb(200, 200, 200);\n"
"    color: rgb(255, 255, 255);\n"
"    border-style: solid;\n"
"    border-radius: 8px;\n"
"    text-align: center;\n"
"}\n"
"\n"
"QProgressBar::chunk {\n"
"    border-radius: 8px;\n"
"    background:rgb(39, 174, 96)\n"
"}\n"
"")
        self.pb_dompet.setValue(0)
        self.pb_dompet.setInvertedAppearance(False)
        self.label_26 = QLabel(self.centralwidget)
        self.label_26.setObjectName(u"label_26")
        self.label_26.setGeometry(QRect(1110, 72, 81, 21))
        self.label_26.setFont(font4)
        self.label_26.setLayoutDirection(Qt.RightToLeft)
        self.label_26.setAutoFillBackground(False)
        self.label_26.setStyleSheet(u"color: rgb(217, 217, 217);\n"
"")
        self.label_26.setTextFormat(Qt.AutoText)
        self.label_26.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)
        self.pb_hp = QProgressBar(self.centralwidget)
        self.pb_hp.setObjectName(u"pb_hp")
        self.pb_hp.setGeometry(QRect(1110, 158, 381, 16))
        self.pb_hp.setFont(font5)
        self.pb_hp.setStyleSheet(u"QProgressBar {\n"
"    background-color: rgb(200, 200, 200);\n"
"    color: rgb(255, 255, 255);\n"
"    border-style: solid;\n"
"    border-radius: 8px;\n"
"    text-align: center;\n"
"}\n"
"\n"
"QProgressBar::chunk {\n"
"    border-radius: 8px;\n"
"    background:rgb(52, 152, 219);\n"
"}\n"
"")
        self.pb_hp.setValue(0)
        self.pb_hp.setInvertedAppearance(False)
        self.label_27 = QLabel(self.centralwidget)
        self.label_27.setObjectName(u"label_27")
        self.label_27.setGeometry(QRect(1110, 130, 31, 21))
        self.label_27.setFont(font4)
        self.label_27.setLayoutDirection(Qt.RightToLeft)
        self.label_27.setAutoFillBackground(False)
        self.label_27.setStyleSheet(u"color: rgb(217, 217, 217);\n"
"")
        self.label_27.setTextFormat(Qt.AutoText)
        self.label_27.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)
        self.pb_pcb = QProgressBar(self.centralwidget)
        self.pb_pcb.setObjectName(u"pb_pcb")
        self.pb_pcb.setGeometry(QRect(1110, 293, 381, 16))
        self.pb_pcb.setFont(font5)
        self.pb_pcb.setStyleSheet(u"QProgressBar {\n"
"    background-color: rgb(200, 200, 200);\n"
"    color: rgb(255, 255, 255);\n"
"    border-style: solid;\n"
"    border-radius: 8px;\n"
"    text-align: center;\n"
"}\n"
"\n"
"QProgressBar::chunk {\n"
"    border-radius: 8px;\n"
"    background:rgb(241, 196, 15)\n"
"}\n"
"")
        self.pb_pcb.setValue(0)
        self.pb_pcb.setInvertedAppearance(False)
        self.pb_pen = QProgressBar(self.centralwidget)
        self.pb_pen.setObjectName(u"pb_pen")
        self.pb_pen.setGeometry(QRect(1110, 360, 381, 16))
        self.pb_pen.setFont(font5)
        self.pb_pen.setStyleSheet(u"QProgressBar {\n"
"    background-color: rgb(200, 200, 200);\n"
"    color: rgb(255, 255, 255);\n"
"    border-style: solid;\n"
"    border-radius: 8px;\n"
"    text-align: center;\n"
"}\n"
"\n"
"QProgressBar::chunk {\n"
"    border-radius: 8px;\n"
"    background:rgb(230, 126, 34)\n"
"}\n"
"")
        self.pb_pen.setValue(0)
        self.pb_pen.setInvertedAppearance(False)
        self.label_28 = QLabel(self.centralwidget)
        self.label_28.setObjectName(u"label_28")
        self.label_28.setGeometry(QRect(1110, 337, 41, 16))
        self.label_28.setFont(font4)
        self.label_28.setLayoutDirection(Qt.RightToLeft)
        self.label_28.setAutoFillBackground(False)
        self.label_28.setStyleSheet(u"color: rgb(217, 217, 217);\n"
"")
        self.label_28.setTextFormat(Qt.AutoText)
        self.label_28.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)
        self.pb_korek = QProgressBar(self.centralwidget)
        self.pb_korek.setObjectName(u"pb_korek")
        self.pb_korek.setGeometry(QRect(1110, 230, 381, 16))
        self.pb_korek.setFont(font5)
        self.pb_korek.setStyleSheet(u"QProgressBar {\n"
"    background-color: rgb(200, 200, 200);\n"
"    color: rgb(255, 255, 255);\n"
"    border-style: solid;\n"
"    border-radius: 8px;\n"
"    text-align: center;\n"
"}\n"
"\n"
"QProgressBar::chunk {\n"
"    border-radius: 8px;\n"
"    background:rgb(142, 68, 173)\n"
"}\n"
"")
        self.pb_korek.setValue(0)
        self.pb_korek.setInvertedAppearance(False)
        self.label_29 = QLabel(self.centralwidget)
        self.label_29.setObjectName(u"label_29")
        self.label_29.setGeometry(QRect(1110, 207, 61, 16))
        self.label_29.setFont(font4)
        self.label_29.setLayoutDirection(Qt.RightToLeft)
        self.label_29.setAutoFillBackground(False)
        self.label_29.setStyleSheet(u"color: rgb(217, 217, 217);\n"
"")
        self.label_29.setTextFormat(Qt.AutoText)
        self.label_29.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)
        self.label_30 = QLabel(self.centralwidget)
        self.label_30.setObjectName(u"label_30")
        self.label_30.setGeometry(QRect(1110, 270, 41, 16))
        self.label_30.setFont(font4)
        self.label_30.setLayoutDirection(Qt.RightToLeft)
        self.label_30.setAutoFillBackground(False)
        self.label_30.setStyleSheet(u"color: rgb(217, 217, 217);\n"
"")
        self.label_30.setTextFormat(Qt.AutoText)
        self.label_30.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)
        self.pb_remot = QProgressBar(self.centralwidget)
        self.pb_remot.setObjectName(u"pb_remot")
        self.pb_remot.setGeometry(QRect(1110, 423, 381, 16))
        self.pb_remot.setFont(font5)
        self.pb_remot.setStyleSheet(u"QProgressBar {\n"
"    background-color: rgb(200, 200, 200);\n"
"    color: rgb(255, 255, 255);\n"
"    border-style: solid;\n"
"    border-radius: 8px;\n"
"    text-align: center;\n"
"}\n"
"\n"
"QProgressBar::chunk {\n"
"    border-radius: 8px;\n"
"    background:rgb(231, 76, 60)\n"
"}\n"
"")
        self.pb_remot.setValue(0)
        self.pb_remot.setInvertedAppearance(False)
        self.pb_sendok = QProgressBar(self.centralwidget)
        self.pb_sendok.setObjectName(u"pb_sendok")
        self.pb_sendok.setGeometry(QRect(1110, 480, 381, 16))
        self.pb_sendok.setFont(font5)
        self.pb_sendok.setStyleSheet(u"QProgressBar {\n"
"    background-color: rgb(200, 200, 200);\n"
"    color: rgb(255, 255, 255);\n"
"    border-style: solid;\n"
"    border-radius: 8px;\n"
"    text-align: center;\n"
"}\n"
"\n"
"QProgressBar::chunk {\n"
"    border-radius: 8px;\n"
"    background:rgb(255, 85, 255)\n"
"}\n"
"")
        self.pb_sendok.setValue(0)
        self.pb_sendok.setInvertedAppearance(False)
        self.label_31 = QLabel(self.centralwidget)
        self.label_31.setObjectName(u"label_31")
        self.label_31.setGeometry(QRect(1110, 457, 71, 16))
        self.label_31.setFont(font4)
        self.label_31.setLayoutDirection(Qt.LeftToRight)
        self.label_31.setAutoFillBackground(False)
        self.label_31.setStyleSheet(u"color: rgb(217, 217, 217);\n"
"")
        self.label_31.setTextFormat(Qt.AutoText)
        self.label_31.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)
        self.label_32 = QLabel(self.centralwidget)
        self.label_32.setObjectName(u"label_32")
        self.label_32.setGeometry(QRect(1110, 400, 71, 16))
        self.label_32.setFont(font4)
        self.label_32.setLayoutDirection(Qt.RightToLeft)
        self.label_32.setAutoFillBackground(False)
        self.label_32.setStyleSheet(u"color: rgb(217, 217, 217);\n"
"")
        self.label_32.setTextFormat(Qt.AutoText)
        self.label_32.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)
        self.label_33 = QLabel(self.centralwidget)
        self.label_33.setObjectName(u"label_33")
        self.label_33.setGeometry(QRect(1110, 517, 61, 16))
        self.label_33.setFont(font4)
        self.label_33.setLayoutDirection(Qt.RightToLeft)
        self.label_33.setAutoFillBackground(False)
        self.label_33.setStyleSheet(u"color: rgb(217, 217, 217);\n"
"")
        self.label_33.setTextFormat(Qt.AutoText)
        self.label_33.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)
        self.pb_solder = QProgressBar(self.centralwidget)
        self.pb_solder.setObjectName(u"pb_solder")
        self.pb_solder.setGeometry(QRect(1110, 540, 381, 16))
        self.pb_solder.setFont(font5)
        self.pb_solder.setStyleSheet(u"QProgressBar {\n"
"    background-color: rgb(200, 200, 200);\n"
"    color: rgb(255, 255, 255);\n"
"    border-style: solid;\n"
"    border-radius: 8px;\n"
"    text-align: center;\n"
"}\n"
"\n"
"QProgressBar::chunk {\n"
"    border-radius: 8px;\n"
"    background:rgb(255, 0, 127)\n"
"}\n"
"")
        self.pb_solder.setValue(0)
        self.pb_solder.setInvertedAppearance(False)
        self.label_34 = QLabel(self.centralwidget)
        self.label_34.setObjectName(u"label_34")
        self.label_34.setGeometry(QRect(1110, 572, 51, 31))
        self.label_34.setFont(font4)
        self.label_34.setLayoutDirection(Qt.RightToLeft)
        self.label_34.setAutoFillBackground(False)
        self.label_34.setStyleSheet(u"color: rgb(217, 217, 217);\n"
"")
        self.label_34.setTextFormat(Qt.AutoText)
        self.label_34.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)
        self.pb_tang = QProgressBar(self.centralwidget)
        self.pb_tang.setObjectName(u"pb_tang")
        self.pb_tang.setGeometry(QRect(1110, 610, 381, 16))
        self.pb_tang.setFont(font5)
        self.pb_tang.setStyleSheet(u"QProgressBar {\n"
"    background-color: rgb(200, 200, 200);\n"
"    color: rgb(255, 255, 255);\n"
"    border-style: solid;\n"
"    border-radius: 8px;\n"
"    text-align: center;\n"
"}\n"
"\n"
"QProgressBar::chunk {\n"
"    border-radius: 8px;\n"
"    background:rgb(85, 255, 127)\n"
"}\n"
"")
        self.pb_tang.setValue(0)
        self.pb_tang.setInvertedAppearance(False)
        self.label_3 = QLabel(self.centralwidget)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setGeometry(QRect(20, 0, 631, 71))
        font6 = QFont()
        font6.setFamilies([u"Siemens Sans Black"])
        font6.setPointSize(33)
        self.label_3.setFont(font6)
        self.label_3.setStyleSheet(u"color: rgb(217, 217, 217);\n"
"")
        self.label_3.setAlignment(Qt.AlignCenter)
        self.label_4 = QLabel(self.centralwidget)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setGeometry(QRect(130, 10, 61, 51))
        self.label_4.setPixmap(QPixmap(u":/icon/lambang-its-white-v1.png"))
        self.label_4.setScaledContents(True)
        self.label_5 = QLabel(self.centralwidget)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setGeometry(QRect(480, 10, 61, 51))
        self.label_5.setPixmap(QPixmap(u":/icon/output-onlinepngtools (1).png"))
        self.label_5.setScaledContents(True)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 1521, 26))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.widget_image.setText("")
        self.pb_choseimage2.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.pb_choseimage.setText(QCoreApplication.translate("MainWindow", u"Chose Image", None))
        self.pb_deletimage.setText(QCoreApplication.translate("MainWindow", u"Delet Image", None))
        self.pb_opencamera.setText("")
        self.pb_closecamera.setText("")
        self.pb_visibleslectarea.setText("")
        self.pb_hideslectarea.setText("")
        self.pb_processImage.setText(QCoreApplication.translate("MainWindow", u"Process Image", None))
        self.pb_captureImage.setText(QCoreApplication.translate("MainWindow", u"Capture", None))
        self.widget_output.setText("")
        self.label_37.setText(QCoreApplication.translate("MainWindow", u"Result:", None))
        self.lbl_result.setText(QCoreApplication.translate("MainWindow", u"-------------", None))
        self.label_35.setText(QCoreApplication.translate("MainWindow", u"Description:", None))
        self.lbl_description.setText(QCoreApplication.translate("MainWindow", u"*-------------------------------------------------------", None))
        self.label_25.setText(QCoreApplication.translate("MainWindow", u"Botol:", None))
        self.pb_botol.setFormat(QCoreApplication.translate("MainWindow", u"%p%", None))
        self.pb_dompet.setFormat(QCoreApplication.translate("MainWindow", u"%p%", None))
        self.label_26.setText(QCoreApplication.translate("MainWindow", u"Dompet :", None))
        self.pb_hp.setFormat(QCoreApplication.translate("MainWindow", u"%p%", None))
        self.label_27.setText(QCoreApplication.translate("MainWindow", u"Hp:", None))
        self.pb_pcb.setFormat(QCoreApplication.translate("MainWindow", u"%p%", None))
        self.pb_pen.setFormat(QCoreApplication.translate("MainWindow", u"%p%", None))
        self.label_28.setText(QCoreApplication.translate("MainWindow", u"Pen:", None))
        self.pb_korek.setFormat(QCoreApplication.translate("MainWindow", u"%p%", None))
        self.label_29.setText(QCoreApplication.translate("MainWindow", u"Korek:", None))
        self.label_30.setText(QCoreApplication.translate("MainWindow", u"Pcb:", None))
        self.pb_remot.setFormat(QCoreApplication.translate("MainWindow", u"%p%", None))
        self.pb_sendok.setFormat(QCoreApplication.translate("MainWindow", u"%p%", None))
        self.label_31.setText(QCoreApplication.translate("MainWindow", u"Sendok:", None))
        self.label_32.setText(QCoreApplication.translate("MainWindow", u"Remot:", None))
        self.label_33.setText(QCoreApplication.translate("MainWindow", u"Solder:", None))
        self.pb_solder.setFormat(QCoreApplication.translate("MainWindow", u"%p%", None))
        self.label_34.setText(QCoreApplication.translate("MainWindow", u"Tang:", None))
        self.pb_tang.setFormat(QCoreApplication.translate("MainWindow", u"%p%", None))
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"Elits Lens", None))
        self.label_4.setText("")
        self.label_5.setText("")
    # retranslateUi

