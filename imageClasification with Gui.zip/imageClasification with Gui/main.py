import sys
import cv2
import os
import numpy as np
import tensorflow as tf
from datetime import datetime
from PySide6.QtCore import QTimer, Qt, QRect, QPoint
from PySide6.QtGui import QPixmap, QImage, QColor, QPainter, QPen
from PySide6.QtWidgets import QApplication, QMainWindow, QFileDialog, QMessageBox
from ui_elitsLens2 import Ui_MainWindow

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.ui.pb_choseimage.clicked.connect(self.choose_image)
        self.ui.pb_choseimage2.clicked.connect(self.choose_image)
        self.ui.pb_deletimage.clicked.connect(self.delete_image)
        self.ui.pb_opencamera.clicked.connect(self.open_camera)
        self.ui.pb_captureImage.clicked.connect(self.capture_image)
        self.ui.pb_closecamera.clicked.connect(self.close_camera)
        self.ui.pb_visibleslectarea.clicked.connect(self.show_bounding_box)
        self.ui.pb_hideslectarea.clicked.connect(self.hide_bounding_box)
        self.ui.pb_processImage.clicked.connect(self.process_image)


        self.current_image_path = None
        self.image_with_bounding_box = None
        self.show_bounding_box_flag = False


        self.cap = None
        self.timer = None
        self.image_capture = None


        self.bounding_box = QRect(50, 50, 200, 150)
        self.is_dragging = False
        self.is_resizing = False
        self.resize_corner = None

    def choose_image(self):

        file, _ = QFileDialog.getOpenFileName(self, "Pilih Gambar", "", "Images (*.png *.xpm *.jpg *.jpeg *.bmp *.gif)")

        if file:

            self.current_image_path = file
            pixmap = QPixmap(file)
            self.ui.widget_image.setPixmap(pixmap)
            self.ui.widget_image.setScaledContents(True)
            self.image_with_bounding_box = pixmap

    def process_image(self):
        """flag potong area dalam bounding box"""
        if self.image_with_bounding_box:
            print("Memulai pemrosesan gambar...")


            pixmap = self.image_with_bounding_box

            image = pixmap.toImage()
            cropped_image = image.copy(self.bounding_box)
            self.ui.widget_output.setPixmap(QPixmap.fromImage(cropped_image).scaled(self.ui.widget_output.size(), Qt.KeepAspectRatio))

            print("Gambar berhasil dipotong. Melakukan prediksi...")
            self.predict_from_cropped_image(cropped_image)

        else:
            print("Tidak ada gambar untuk diproses.")

    def preprocess_image(self, image):
        """Preprocess image for prediction using a deep learning model."""
        img = self.convert_qimage_to_opencv(image)
        img_resized = cv2.resize(img, (224, 224))
        img_array = np.array(img_resized, dtype=np.float32)
        img_batch = np.expand_dims(img_array, axis=0)
        img_preprocessed = tf.keras.applications.resnet.preprocess_input(img_batch)
        return img, img_preprocessed

    def convert_qimage_to_opencv(self, qimage):
        """Mengonversi QImage ke format OpenCV (numpy array)."""
        width = qimage.width()
        height = qimage.height()
        ptr = qimage.bits()

        img_array = np.frombuffer(ptr, dtype=np.uint8).reshape((height, width, 4))  # 4 untuk RGBA
        img_bgr = cv2.cvtColor(img_array, cv2.COLOR_RGBA2BGR)
        return img_bgr

    def convert_opencv_to_qimage(self, img_bgr):
        """Mengonversi OpenCV BGR ke QImage untuk ditampilkan di widget_output."""
        img_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
        height, width, channel = img_rgb.shape
        bytes_per_line = channel * width
        qimage = QImage(img_rgb.data, width, height, bytes_per_line, QImage.Format_RGB888)

        return qimage

    def predict_from_cropped_image(self, cropped_image):
        """Melakukan prediksi pada gambar yang telah dipotong dan menampilkan hasilnya."""
        print("Proses prediksi dimulai...")
        model_path = 'cerdasclasification2.h5'
        class_labels = ['Botol', 'Dompet', 'Hp', 'Korek', 'Pcb', 'Pen', 'Remot', 'Sendok', 'Solder', 'Tang']

        img, img_preprocessed = self.preprocess_image(cropped_image)
        try:
            model = tf.keras.models.load_model(model_path)
            print(f"Model berhasil dimuat dari {model_path}")
        except Exception as e:
            print(f"Error saat memuat model: {e}")
            return
        preds = model.predict(img_preprocessed)
        label, probability = self.decode_predictions(preds, class_labels)

        botol_probability = preds[0][class_labels.index('Botol')] * 100
        Dompet_probability = preds[0][class_labels.index('Dompet')] * 100
        hp_probability = preds[0][class_labels.index('Hp')] * 100
        Korek_probability = preds[0][class_labels.index('Korek')] * 100
        Pcb_probability = preds[0][class_labels.index('Pcb')] * 100
        Pen_probability = preds[0][class_labels.index('Pen')] * 100
        Remot_probability = preds[0][class_labels.index('Remot')] * 100
        Sendok_probability = preds[0][class_labels.index('Sendok')] * 100
        Solder_probability = preds[0][class_labels.index('Solder')] * 100
        Tang_probability = preds[0][class_labels.index('Tang')] * 100

        self.ui.pb_botol.setValue(botol_probability)
        self.ui.pb_dompet.setValue(Dompet_probability)
        self.ui.pb_hp.setValue(hp_probability)
        self.ui.pb_korek.setValue(Korek_probability)
        self.ui.pb_pcb.setValue(Pcb_probability)
        self.ui.pb_pen.setValue(Pen_probability)
        self.ui.pb_remot.setValue(Remot_probability)
        self.ui.pb_sendok.setValue(Sendok_probability)
        self.ui.pb_solder.setValue(Solder_probability)
        self.ui.pb_tang.setValue(Tang_probability)
        print(f"Hasil Prediksi: {label} dengan Probabilitas {probability * 100:.2f}%")
        self.display_prediction_result(cropped_image, label, probability)

    def decode_predictions(self, preds, class_labels):
        """Mendekode hasil prediksi."""
        class_id = np.argmax(preds)
        class_label = class_labels[class_id]
        class_probability = preds[0][class_id]
        return class_label, class_probability

    def display_prediction_result(self, cropped_image, label, probability):
        """Menampilkan hasil prediksi pada widget_output."""
        text = f"{label}: {probability * 100:.2f}%"
        font = cv2.FONT_HERSHEY_SIMPLEX
        img_resized = self.convert_qimage_to_opencv(cropped_image)

        cv2.putText(img_resized, text, (10, 30), font, 1, (255, 0, 0), 2, cv2.LINE_AA)

        result_image = self.convert_opencv_to_qimage(img_resized)

        result_pixmap = QPixmap.fromImage(result_image)
        #self.ui.widget_output.setPixmap(result_pixmap.scaled(self.ui.widget_output.size(), Qt.KeepAspectRatio))
        print(f"Predicted Label: {label}, Probability: {probability * 100:.2f}%")


        if label == 'Botol':
            self.ui.lbl_result.setText(f"Botol: {probability * 100:.2f}%")
            self.ui.lbl_description.setText('Objek Yang terklasifikasi adalah BOTOL. Botol adalah wadah penyimpanan yang memiliki leher lebih sempit daripada badan dan mulutnya. '
                                            'Botol biasanya terbuat dari gelas, plastik, atau aluminium. Botol digunakan untuk menyimpan cairan '
                                            'seperti air, susu, kopi, minuman ringan, bir, anggur, obat, sabun cair, dan tinta.')
        elif label == 'Dompet':
            self.ui.lbl_result.setText(f"Dompet: {probability * 100:.2f}%")
            self.ui.lbl_description.setText('Objek Yang terklasifikasi adalah DOMPET .Dompet adalah kantong atau kotak datar yang digunakan untuk membawa barang-barang pribadi kecil, seperti: Mata uang, Kartu kredit, '
                                            'Kartu identitas, Kartu klub, Foto, Kartu transit, Kartu nama, Kertas lain atau kartu laminasi. '
                                            ' Dompet dapat terbuat dari kulit sintetis atau kulit yang awet dan tidak mudah robek. '
                                            'Dompet juga dapat memiliki berbagai desain dan warna, seperti merah, biru, hitam, dan hijau')
        elif label == 'Hp':
            self.ui.lbl_result.setText(f"Hp: {probability * 100:.2f}%")
            self.ui.lbl_description.setText('Objek Yang terklasifikasi adalah Hp/Smartphone. Hp/Smartphone adalah telepon genggam yang memiliki fungsi seperti komputer, seperti kamera, bluetooth, akses internet, dan lain-lain. Smartphone juga memiliki sistem operasi (OS) '
                                            'yang memungkinkan pengguna untuk menambahkan aplikasi, mengubah fungsi, atau menyesuaikan sesuai keinginan.')
        elif label == 'Korek':
            self.ui.lbl_result.setText(f"Korek: {probability * 100:.2f}%")
            self.ui.lbl_description.setText('Objek Yang terklasifikasi adalah KOREK. Korek adalah alat untuk menyalakan api secara terkendali Korek api ini menggunakan gas seperti butana atau naphtha sebagai bahan bakar. Untuk menyalakannya, gesekkan batu api pada permukaan kasar untuk menghasilkan percikan, '
                                            'lalu percikan tersebut akan menyulut gas atau cairan sehingga tercipta api. Korek api gas dilengkapi dengan mekanisme pengaman untuk mencegah kebocoran gas.')
        elif label == 'Pcb':
            self.ui.lbl_result.setText(f"Pcb: {probability * 100:.2f}%")
            self.ui.lbl_description.setText('Objek Yang terklasifikasi adalah PCB.PCB (Printed Circuit Board) atau papan sirkuit cetak adalah papan yang menghubungkan komponen elektronik dengan jalur tembaga. '
                                            'PCB merupakan komponen penting dalam rangkaian elektronik karena dapat memperkecil ukuran dan meningkatkan keandalan sirkuit')
        elif label == 'Pen':
            self.ui.lbl_result.setText(f"Pen: {probability * 100:.2f}%")
            self.ui.lbl_description.setText('Objek Yang terklasifikasi adalah PEN/PULPEN.Pulpen adalah alat tulis yang memiliki mata pena berujung tajam dan pegangan yang berisi kantong tinta yang dapat diisi ulang. '
                                            'Pulpen digunakan untuk menulis atau menggambar di atas permukaan seperti kertas.')
        elif label == 'Remot':
            self.ui.lbl_result.setText(f"Remot: {probability * 100:.2f}%")
            self.ui.lbl_description.setText('Objek Yang terklasifikasi adalah PREMOT.Remote atau pengendali jarak jauh adalah alat elektronik yang digunakan untuk mengoperasikan perangkat atau mesin dari jarak jauh. Remote biasanya berupa benda kecil nirkabel '
                                            'yang dipegang di tangan dan memiliki sederetan tombol untuk mengatur berbagai setting')
        elif label == 'Sendok':
            self.ui.lbl_result.setText(f"Sendok: {probability * 100:.2f}%")
            self.ui.lbl_description.setText('Objek Yang terklasifikasi adalah SENDOK.Sendok adalah alat makan yang berbentuk cekung dan oval, dengan satu ujung berbentuk lonjong atau bulat lonjong dan ujung lainnya berbentuk gagang. Sendok digunakan untuk mengambil makanan, baik makanan cair, setengah cair, '
                                            'maupun padat. Sendok juga digunakan dalam memasak dan menyajikan makanan')
        elif label == 'Solder':
            self.ui.lbl_result.setText(f"Solder: {probability * 100:.2f}%")
            self.ui.lbl_description.setText('Objek Yang terklasifikasi adalah SOLDER.older adalah alat pemanas yang digunakan untuk melelehkan timah atau logam pengisi lainnya untuk menyambungkan dua material logam atau komponen elektronik')
        elif label == 'Tang':
            self.ui.lbl_result.setText(f"Tang: {probability * 100:.2f}%")
            self.ui.lbl_description.setText('Objek Yang terklasifikasi adalah TANG.Tang adalah alat perkakas yang berfungsi untuk memegang, memotong, melepas, dan memasang bahan kerja. Tang memiliki banyak jenis dan fungsi, di antaranya: Tang kombinasi Tang yang paling umum digunakan, '
                                            'dengan ujung penjepit lancip dan pegangan dari bahan isolator. Tang ini dapat digunakan untuk menjepit kabel, memotong kabel dan kawat, dan menahan bahan kerja. Tang buaya Tang ini berfungsi untuk menjepit suatu benda yang bulat seperti mur dan kepala baut. '
                                            'Tang buaya juga disebut sebagai tang jepit atau locking pliers. Tang potong Memiliki desain tajam seperti gunting khusus yang berfungsi memotong kabel maupun mengupas kulit kabel. Tang umumnya memiliki lima bagian utama, yaitu jaw atau rahang, nose atau ujung rahang, cutter atau pemotong, pivot atau sambungan tang, dan handle (pegangan).')
        else:
            self.ui.lbl_result.setText('-------------')
            self.ui.lbl_description.setText('*-------------------------------------------------------')

        QMessageBox.information(self, "Process prediction has completed!", "The process has finished successfully.",
                                QMessageBox.Ok)

    def delete_image(self):
        default_image_path = "icon/Desain tanpa judul.png"
        default_image_path_result = "icon/Please Insert Image (1).png"
        pixmap = QPixmap(default_image_path)
        pixmap2 = QPixmap(default_image_path_result)

        if not pixmap.isNull() and not pixmap2.isNull():
            self.ui.widget_image.setPixmap(pixmap.scaled(self.ui.widget_image.size(), Qt.KeepAspectRatio))
            self.ui.widget_output.setPixmap(pixmap2.scaled(self.ui.widget_output.size(), Qt.KeepAspectRatio))

            self.ui.pb_botol.setValue(0)
            self.ui.pb_dompet.setValue(0)
            self.ui.pb_hp.setValue(0)
            self.ui.pb_korek.setValue(0)
            self.ui.pb_pcb.setValue(0)
            self.ui.pb_pen.setValue(0)
            self.ui.pb_remot.setValue(0)
            self.ui.pb_sendok.setValue(0)
            self.ui.pb_solder.setValue(0)
            self.ui.pb_tang.setValue(0)

            self.ui.lbl_result.setText('-------------')
            self.ui.lbl_description.setText('*-------------------------------------------------------')

        else:
            if pixmap.isNull():
                self.ui.lblimg_insertImage.setText("No source images")
            if pixmap2.isNull():
                self.ui.widget_output.setText("No source images")

    def show_bounding_box(self):
        """Menampilkan bounding box dengan garis hanya di sudut-sudut bounding box dan outline bounding box berwarna putih."""
        if self.image_with_bounding_box:
            pixmap = self.image_with_bounding_box.copy()

            painter = QPainter(pixmap)
            painter.setRenderHint(QPainter.Antialiasing)


            painter.setOpacity(0.4)
            painter.fillRect(pixmap.rect(), QColor(0, 0, 0))


            painter.setOpacity(1.0)
            painter.setBrush(Qt.transparent)
            painter.drawRect(self.bounding_box)


            outline_pen = QPen(Qt.white)
            outline_pen.setWidth(3)
            outline_pen.setCapStyle(Qt.RoundCap)
            outline_pen.setJoinStyle(Qt.RoundJoin)
            painter.setPen(outline_pen)
            painter.drawRect(self.bounding_box)


            corner_length = 100
            pen = QPen(Qt.white)
            pen.setWidth(10)
            pen.setCapStyle(Qt.RoundCap)
            pen.setJoinStyle(Qt.RoundJoin)
            painter.setPen(pen)


            painter.drawLine(self.bounding_box.topLeft(),
                             self.bounding_box.topLeft() + QPoint(corner_length, 0))
            painter.drawLine(self.bounding_box.topLeft(),
                             self.bounding_box.topLeft() + QPoint(0, corner_length))

            painter.drawLine(self.bounding_box.topRight(),
                             self.bounding_box.topRight() + QPoint(-corner_length, 0))
            painter.drawLine(self.bounding_box.topRight(),
                             self.bounding_box.topRight() + QPoint(0, corner_length))

            painter.drawLine(self.bounding_box.bottomLeft(),
                             self.bounding_box.bottomLeft() + QPoint(corner_length, 0))
            painter.drawLine(self.bounding_box.bottomLeft(),
                             self.bounding_box.bottomLeft() + QPoint(0, -corner_length))

            painter.drawLine(self.bounding_box.bottomRight(),
                             self.bounding_box.bottomRight() + QPoint(-corner_length, 0))
            painter.drawLine(self.bounding_box.bottomRight(),
                             self.bounding_box.bottomRight() + QPoint(0, -corner_length))
            painter.end()

            self.ui.widget_image.setPixmap(pixmap.scaled(self.ui.widget_image.size(), Qt.KeepAspectRatio))

        self.show_bounding_box_flag = True


    def hide_bounding_box(self):
        if self.image_with_bounding_box:
            self.ui.widget_image.setPixmap(
                self.image_with_bounding_box.scaled(self.ui.widget_image.size(), Qt.KeepAspectRatio))

        self.show_bounding_box_flag = False

    def open_camera(self):
        self.cap = cv2.VideoCapture(0)

        if not self.cap.isOpened():
            print("Tidak dapat membuka kamera.")
            return
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_frame)
        self.timer.start(30)

    def update_frame(self):

        ret, frame = self.cap.read()
        frame = cv2.flip(frame, 1)
        if ret:

            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

            h, w, ch = rgb_frame.shape
            bytes_per_line = ch * w
            qt_image = QImage(rgb_frame.data, w, h, bytes_per_line, QImage.Format_RGB888)

            pixmap = QPixmap.fromImage(qt_image)

            if not pixmap.isNull():
                self.ui.widget_image.setPixmap(pixmap.scaled(self.ui.widget_image.size(), Qt.KeepAspectRatio))



    def capture_image(self):
        if self.cap:
            ret, frame = self.cap.read()
            frame = cv2.flip(frame, 1)
            if ret:
                rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

                h, w, ch = rgb_frame.shape
                bytes_per_line = ch * w
                qt_image = QImage(rgb_frame.data, w, h, bytes_per_line, QImage.Format_RGB888)

                pixmap = QPixmap.fromImage(qt_image)
                if not pixmap.isNull():
                    self.ui.widget_image.setPixmap(pixmap.scaled(self.ui.widget_image.size(),
                                                                 Qt.KeepAspectRatio))
                    self.ui.widget_image.setScaledContents(True)
                    print("Gambar berhasil ditangkap dan ditampilkan")

                    if self.timer:
                        self.timer.stop()

                    save_directory = "image"
                    if not os.path.exists(save_directory):
                        os.makedirs(save_directory)
                    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
                    save_path = os.path.join(save_directory, f"captured_image_{timestamp}.png")
                    cv2.imwrite(save_path,
                                cv2.cvtColor(rgb_frame, cv2.COLOR_RGB2BGR))

                    #QMessageBox.information(self, "Image has been successfully captured", f"Image saved in {save_path}", QMessageBox.Ok).setStyleSheet("QLabel { color: white; }", QMessageBox.Ok)

                    print(f"Gambar berhasil disimpan di {save_path}")

                    saved_pixmap = QPixmap(save_path)

                    if not saved_pixmap.isNull():
                        self.ui.widget_image.setPixmap(
                            saved_pixmap.scaled(self.ui.widget_image.size(), Qt.KeepAspectRatio))

                        self.image_with_bounding_box = saved_pixmap  # Set image with bounding box to saved image
                       # self.show_bounding_box()

                    else:
                        print("Gagal memuat gambar yang disimpan.")

                    self.close_camera()

                else:
                    print("Gagal mengonversi frame ke QPixmap.")
            else:
                print("Gagal menangkap gambar.")
        else:
            print("Kamera tidak dibuka.")

    def close_camera(self):
        if self.cap:
            if self.timer:
                self.timer.stop()

            self.cap.release()

            self.ui.widget_image.show()

            print("Kamera ditutup dan stream video dihentikan.")

    def closeEvent(self, event):
        if self.cap:
            self.cap.release()

        event.accept()

    def mousePressEvent(self, event):
        if self.show_bounding_box_flag:
            if self.bounding_box.contains(event.pos()):
                self.is_dragging = True
                self.offset = event.pos() - self.bounding_box.topLeft()
            else:
                self.is_resizing = self.check_resize_area(event.pos())

    def mouseMoveEvent(self, event):
        if self.is_dragging:
            new_pos = event.pos() - self.offset
            self.bounding_box.moveTopLeft(new_pos)
            self.show_bounding_box()
        elif self.is_resizing:
            self.resize_bounding_box(event.pos())
            self.show_bounding_box()

    def mouseReleaseEvent(self, event):
        self.is_dragging = False
        self.is_resizing = False

    def check_resize_area(self, pos):
        """Check if the mouse is near one of the corners or edges of the bounding box for resizing."""
        margin = 50
        if self.bounding_box.contains(pos):
            return True
        if (self.bounding_box.topLeft() - pos).manhattanLength() < margin:
            self.resize_corner = 'topLeft'
            return True
        elif (self.bounding_box.topRight() - pos).manhattanLength() < margin:
            self.resize_corner = 'topRight'
            return True
        elif (self.bounding_box.bottomLeft() - pos).manhattanLength() < margin:
            self.resize_corner = 'bottomLeft'
            return True
        elif (self.bounding_box.bottomRight() - pos).manhattanLength() < margin:
            self.resize_corner = 'bottomRight'
            return True
        elif abs(self.bounding_box.left() - pos.x()) < margin:
            self.resize_corner = 'left'
            return True
        elif abs(self.bounding_box.right() - pos.x()) < margin:
            self.resize_corner = 'right'
            return True
        elif abs(self.bounding_box.top() - pos.y()) < margin:
            self.resize_corner = 'top'
            return True
        elif abs(self.bounding_box.bottom() - pos.y()) < margin:
            self.resize_corner = 'bottom'
            return True

        return False

    def resize_bounding_box(self, pos):
        if self.resize_corner == 'topLeft':

            new_rect = QRect(pos, self.bounding_box.bottomRight())
            self.bounding_box = new_rect.normalized()
        elif self.resize_corner == 'topRight':

            new_rect = QRect(self.bounding_box.topLeft(), pos)
            new_rect.setTopRight(pos)
            self.bounding_box = new_rect.normalized()
        elif self.resize_corner == 'bottomLeft':

            new_rect = QRect(pos.x(), self.bounding_box.top(), self.bounding_box.right() - pos.x(), self.bounding_box.height())
            self.bounding_box = new_rect.normalized()
        elif self.resize_corner == 'bottomRight':

            self.bounding_box.setBottomRight(pos)
        elif self.resize_corner == 'left':

            self.bounding_box.setLeft(pos.x())
        elif self.resize_corner == 'right':

            self.bounding_box.setRight(pos.x())
        elif self.resize_corner == 'top':

            self.bounding_box.setTop(pos.y())
        elif self.resize_corner == 'bottom':

            self.bounding_box.setBottom(pos.y())

        self.show_bounding_box()




if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
