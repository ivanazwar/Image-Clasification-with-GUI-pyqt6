import os
import numpy as np
import cv2
import tensorflow as tf

os.environ['CUDA_VISIBLE_DEVICES'] = '-1'

def preprocess_image(image_path):
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError(f"Error loading image at path: {image_path}")
    img_resized = cv2.resize(img, (224, 224))
    img_array = np.array(img_resized, dtype=np.float32)
    img_batch = np.expand_dims(img_array, axis=0)
    img_preprocessed = tf.keras.applications.resnet.preprocess_input(img_batch)
    return img, img_preprocessed

def predict_image(model_path, image_path):
    img, img_preprocessed = preprocess_image(image_path)
    model = tf.keras.models.load_model(model_path)
    preds = model.predict(img_preprocessed)  #
    return img, preds

def decode_predictions(preds, class_labels):
    class_id = np.argmax(preds)
    class_label = class_labels[class_id]
    class_probability = preds[0][class_id]
    return class_label, class_probability

def resize_image(image_path):
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError("Could not open or find the image: " + image_path)
    resized_img = cv2.resize(img, (640, 480))
    return resized_img

model_path = 'cerdasclasification2.h5'
image_path = "lee.jpg"
class_labels = ['Botol', 'Dompet', 'Hp', 'Korek', 'Pcb', 'Pen', 'Remot', 'Sendok', 'Solder', 'Tang']

#model_path = 'E:\\IVAN M.T\\COBA\\coba\\training2.h5'
#image_path = "E:/IVAN M.T/COBA/coba/img/plastik2.jpg"  # Pastikan ini adalah file gambar yang benar
#image_path = "E:\\IVAN M.T\\COBA\\coba\\plastik2.jpg"
#class_labels = ['flower', 'plastik', 'wood']  # Ganti dengan label kelas aktual Anda

resized_img = resize_image(image_path)
img, preds = predict_image(model_path, image_path)
label, probability = decode_predictions(preds, class_labels)
font = cv2.FONT_HERSHEY_SIMPLEX
text = f"{label}: {probability * 100:.2f}%"
cv2.putText(resized_img, text, (10, 30), font, 1, (255, 0, 0), 2, cv2.LINE_AA)
cv2.imshow('Prediction', resized_img)
#cv2.imshow('Prediction', img_preprocessed)
cv2.waitKey(0)
cv2.destroyAllWindows()
